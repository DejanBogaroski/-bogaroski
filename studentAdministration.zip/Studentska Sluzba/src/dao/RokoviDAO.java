package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Rok;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RokoviDAO {
	
	private static Logger log = LogManager.getLogger(StudentDAO.class.getName());
	
	public Rok getRokById(Connection conn, int id) {
		Rok rok = null;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt
					.executeQuery("SELECT rok FROM rokovi WHERE rokovi_id = " + id);

			if (rset.next()) {
				String rokS = rset.getString(1);
				
				rok = new Rok(id, rokS);
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne moze se ucitati rok sa id: " + id);
		}
		return rok;
	}
	
	public List<Rok> getAll(Connection conn) {
		List<Rok> retVal = new ArrayList<Rok>();
		try {
			String query = "SELECT ispitnirok_id, mesec FROM rokovi ";
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery(query.toString());
			while (rset.next()) {
				int id = rset.getInt(1);
				String mesec = rset.getString(2);
				
				Rok rok = new Rok(id, mesec);
				retVal.add(rok);
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se ucitati studenti");
		}
		return retVal;
	}
	
	public boolean add(Connection conn, Rok rok){
		boolean retVal = false;
		try {
			String update = "INSERT INTO rokovi (mesec) values (?)";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setString(1, rok.getMesec());
			if(pstmt.executeUpdate() == 1){
				retVal = true;
				rok.setId(getInsertedId(conn));
			}
			pstmt.close();
		} catch (SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se dodati rok: " + rok);
		}
		return retVal;
	}
	
	protected int getInsertedId(Connection conn) throws SQLException {
		String query = "SELECT LAST_INSERT_ID();";
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery(query);
		int retVal = -1;
		if (rset.next())
			retVal = rset.getInt(1);
		rset.close();
		stmt.close();
		return retVal;
	}

}