package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import model.Predmet;
import model.Rok;
import model.Student;

public class PrijavaIspitaDAO {
	
	private static Logger log = LogManager.getLogger(PredmetDAO.class.getName());
	
	StudentDAO studentDAO = new StudentDAO();
	PredmetDAO predmetDAO = new PredmetDAO();
	RokoviDAO rokDAO = new RokoviDAO();
	
	public boolean add(Connection conn, Student student, Predmet predmet, Rok rok){
		boolean retVal = false;
		try {
			String update = "INSERT INTO prijavaispita (student_id, predmet_id) values (?,?)";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setInt(1, student.getId());
			pstmt.setInt(2, predmet.getId());
			if(pstmt.executeUpdate() == 1)
				retVal = true;
			pstmt.close();
		} catch (SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se dodati pohadjanje sa studenta sa id:  " + student.getId() + " i za predmet sa id: " + predmet.getId());
		}
		return retVal;
	}
	
	public List<Predmet> getPredmetiByStudentId(Connection conn, int id) {
		List<Predmet> retVal = new ArrayList<Predmet>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt
					.executeQuery("SELECT predmet_id FROM pohadja WHERE student_id = " + id);

			while (rset.next()) {
				int predmetId = rset.getInt(1);
				retVal.add(predmetDAO.getPredmetById(conn, predmetId));
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se ucitati predmeti za studenta sa id: " + id);
		}
		return retVal;
	}

}