package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Predmet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PredmetDAO {

	private static Logger log = LogManager.getLogger(PredmetDAO.class.getName());
	
	public Predmet getPredmetById(Connection conn, int id) {
		Predmet predmet = null;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt
					.executeQuery("SELECT naziv FROM predmeti WHERE predmet_id = " + id);
			if (rset.next()) {
				String naziv = rset.getString(1);
				
				predmet = new Predmet(id, naziv);
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne moze se ucitati predmet sa id: " + id);
		}
		return predmet;
	}
	
	public List<Predmet> getAll(Connection conn) {
		List<Predmet> retVal = new ArrayList<Predmet>();
		try {
			String query = "SELECT predmet_id, naziv FROM predmeti ";
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery(query.toString());
			while (rset.next()) {
				int id = rset.getInt(1);
				String naziv = rset.getString(2);
				
				Predmet predmet = new Predmet(id, naziv);
				retVal.add(predmet);
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se ucitati predmeti");
		}
		return retVal;
	}
	
	public List<Predmet> getAll(Connection conn, String orderClause) {
		List<Predmet> retVal = new ArrayList<Predmet>();
		try {
			String query = "SELECT predmet_id, naziv FROM predmeti ORDER BY " + orderClause;
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery(query.toString());
			while (rset.next()) {
				int id = rset.getInt(1);
				String naziv = rset.getString(2);
				
				Predmet predmet = new Predmet(id, naziv);
				retVal.add(predmet);
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se ucitati predmeti");
		}
		return retVal;
	}

	public boolean add(Connection conn, Predmet predmet){
		boolean retVal = false;
		try {
			String update = "INSERT INTO predmeti (naziv) values (?)";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setString(1, predmet.getNaziv());
			if(pstmt.executeUpdate() == 1){
				retVal = true;
				predmet.setId(getInsertedId(conn));
			}
			pstmt.close();
		} catch (SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se dodati predmet: " + predmet);
		}
		return retVal;
	}
	
	protected int getInsertedId(Connection conn) throws SQLException {
		String query = "SELECT LAST_INSERT_ID();";
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery(query);
		int retVal = -1;
		if (rset.next())
			retVal = rset.getInt(1);
		rset.close();
		stmt.close();
		return retVal;
	}

	public boolean update(Connection conn, Predmet predmet) {
		boolean retVal = false;
		try {
			String update = "UPDATE predmeti SET naziv=? WHERE predmet_id=?";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setString(1, predmet.getNaziv());
			pstmt.setInt(2, predmet.getId());
			if(pstmt.executeUpdate() == 1)
				retVal = true;
			pstmt.close();
		} catch (SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se izmeniti predmet: " + predmet);
		}
		return retVal;
	}
	
	public boolean delete(Connection conn, Predmet predmet) {
		return delete(conn, predmet.getId());
	}

	public boolean delete(Connection conn, int id) {
		boolean retVal = false;
		try {
			String update = "DELETE FROM predmeti WHERE predmet_id = " + id;
			Statement stmt = conn.createStatement();
			if(stmt.executeUpdate(update) == 1)
				retVal = true;
			stmt.close();
		} catch (SQLException ex) {
			log.fatal(ex);
			log.fatal("Ne moze se obrisati predmet sa id: " + id);
		}
		return retVal;
	}
	
}