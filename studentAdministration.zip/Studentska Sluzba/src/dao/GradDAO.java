package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import model.Grad;

public class GradDAO {
	
	private static Logger log = LogManager.getLogger(GradDAO.class.getName());

	public Grad getGradByID(Connection conn, int id) {
		Grad grad = null;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt
					.executeQuery("SELECT naziv, ptt FROM grad WHERE grad_id = " + id);
			
			if(rset.next()) {
				String naziv = rset.getString(1);
				String ptt = rset.getString(2);
				
				grad = new Grad(naziv, id, ptt);
			}
			rset.close();
			stmt.close();
		} catch (Exception e) {
			log.fatal(e);
			log.fatal("Ne moze se obrisati grad sa id: " + id);
		}
		return grad;
	}
	
	public List<Grad> getAll(Connection conn) {
		List<Grad> retVal = new ArrayList<Grad>();
		try {
			String query = "SELECT grad_id, naziv, ptt FROM grad";
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery(query.toString());
			while (rset.next()) {
				int id = rset.getInt(1);
				String naziv = rset.getString(2);
				String ptt = rset.getString(3);
				
				Grad grad = new Grad(naziv, id, ptt);
				retVal.add(grad);
			}
			rset.close();
			stmt.close();
		}catch (Exception e) {
			log.fatal(e);
			log.fatal("Ne mogu se ucitati gradovi");
		}
		return retVal;
	}
	
	public boolean add(Connection conn, Grad grad){
		boolean retVal = false;
		try {
			String update = "INSERT INTO grad (naziv, ptt) values (?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setString(1, grad.getNaziv());
			pstmt.setString(2, grad.getPtt());
			if(pstmt.executeUpdate() == 1){
				retVal = true;
				grad.setId(getInsertedId(conn));
			}
			pstmt.close();
		} catch (SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se dodati grad: " + grad);
		}
		return retVal;
	}
	
	public int getInsertedId(Connection conn) throws SQLException {
		String query = "SELECT LAST_INSERT_ID();";
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery(query);
		int retVal = -1;
		if (rset.next())
			retVal = rset.getInt(1);
		rset.close();
		stmt.close();
		return retVal;
	}
	
	public boolean update(Connection conn, Grad grad) {
		boolean retVal = false;
		try {
			String update = "UPDATE grad SET naziv=?, ptt=? WHERE grad_id=?";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setString(1, grad.getNaziv());
			pstmt.setString(2, grad.getPtt());
			pstmt.setInt(3, grad.getId());
			if(pstmt.executeUpdate() == 1)
				retVal = true;
			pstmt.close();
		} catch(SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se izmeniti grad: " + grad);
		}
		return retVal;
	}
	
	public boolean delete(Connection conn, int id) {
		boolean retVal = false;
		try {
			String update = "DELETE FROM grad WHERE grad_id = " + id;
			Statement stmt = conn.createStatement();
			if(stmt.executeUpdate(update) == 1)
				retVal = true;
			stmt.close();
		} catch (SQLException ex) {
			log.fatal(ex);
			log.fatal("Ne moze se obrisati grad sa id: " + id);
		}
		return retVal;
	}
	
	public boolean delete(Connection conn, Grad grad) {
		return delete(conn, grad.getId());
	}
	
}