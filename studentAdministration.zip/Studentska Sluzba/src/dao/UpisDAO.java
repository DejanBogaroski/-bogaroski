package dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import ui.ApplicationUI;
import model.Student;

public class UpisDAO {

	private StudentDAO studentDAO = new StudentDAO();
	private  List<Student> studenti = new ArrayList<Student>();

	public void upisi() {
		String sP = System.getProperty("file.separator");
		File file = new File("."+sP + "klass.txt");
		studenti = studentDAO.getAll(ApplicationUI.conn);
		try {
			PrintWriter pw = new PrintWriter(new FileWriter(file));
			pw.println("*****************");
			for (Student s: studenti) {
			pw.println(s.getId()+", " + s.getIme() + " " + s.getPrezime() + ", " + s.getGrad() + ", " + s.getIndeks());
		}
			pw.flush();
			pw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}