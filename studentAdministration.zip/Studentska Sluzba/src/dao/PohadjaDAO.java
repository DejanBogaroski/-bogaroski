package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Predmet;
import model.Student;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PohadjaDAO {
	
	private static Logger log = LogManager.getLogger(PredmetDAO.class.getName());
	
	private StudentDAO studentDAO = new StudentDAO();
	private PredmetDAO predmetDAO = new PredmetDAO();
	
	public List<Predmet> getPredmetiByStudent(Connection conn, Student student) {
		return getPredmetiByStudentId(conn, student.getId());
	}
	
	public List<Predmet> getPredmetiByStudentId(Connection conn, int id) {
		List<Predmet> retVal = new ArrayList<Predmet>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt
					.executeQuery("SELECT predmet_id FROM pohadja WHERE student_id = " + id);

			while (rset.next()) {
				int predmetId = rset.getInt(1);
				retVal.add(predmetDAO.getPredmetById(conn, predmetId));
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se ucitati predmeti za studenta sa id: " + id);
		}
		return retVal;
	}
	
	public List<Student> getStudentiByPredmet(Connection conn, Predmet predmet) {
		return getStudentiByPredmetId(conn, predmet.getId());
	}
	
	public List<Student> getStudentiByPredmetId(Connection conn, int id) {
		List<Student> retVal = new ArrayList<Student>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt
					.executeQuery("SELECT student_id FROM pohadja WHERE predmet_id = " + id);

			while (rset.next()) {
				int studentId = rset.getInt(1);
				retVal.add(studentDAO.getStudentById(conn, studentId));
			}
			rset.close();
			stmt.close();
		} catch (Exception ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se ucitati studenti za predmet sa id: " + id);
		}
		return retVal;
	}
	
	public boolean add(Connection conn, Student student, Predmet predmet){
		return add(conn, student.getId(), predmet.getId());
	}
	
	public boolean add(Connection conn, int studentId, int predmetId){
		boolean retVal = false;
		try {
			String update = "INSERT INTO pohadja (student_id, predmet_id) values (?,?)";
			PreparedStatement pstmt = conn.prepareStatement(update);
			pstmt.setInt(1, studentId);
			pstmt.setInt(2, predmetId);
			if(pstmt.executeUpdate() == 1)
				retVal = true;
			pstmt.close();
		} catch (SQLException e) {
			log.fatal(e);
			log.fatal("Ne moze se dodati pohadjanje sa studenta sa id:  " + studentId + " i za predmet sa id: " + predmetId);
		}
		return retVal;
	}
	
	public boolean update(Connection conn, Student student){
		boolean retVal = false;
		try {
			retVal = delete(conn, student);
			if(retVal){
				for (Predmet predmet : student.getPredmeti()) {
					retVal = add(conn, student, predmet);
					if(retVal == false)
						throw new Exception("Dodavanje nije valjalo");
				}
			} else {
				throw new Exception("Brisanje nije valjalo");
			}
		} catch (Exception e) {
			log.fatal(e);
			log.fatal(e.getMessage());
			log.fatal("Ne mogu se update-ovai pohadjanja sa studenta sa id:  " + student.getId());
		}
		return retVal;
	}
	
	public boolean update(Connection conn, Predmet predmet){
		boolean retVal = false;
		try {
			retVal = delete(conn, predmet);
			if(retVal){
				for (Student student : predmet.getStudenti()) {
					retVal = add(conn, student, predmet);
					if(retVal == false)
						throw new Exception("Dodavanje nije valjalo");
				}
			} else {//			
				throw new Exception("Brisanje nije valjalo");
			}
		} catch (Exception e) {
			log.fatal(e);
			log.fatal(e.getMessage());
			log.fatal("Ne mogu se update-ovai pohadjanja sa predmet sa id:  " + predmet.getId());
		}
		return retVal;
	}
	
	public boolean delete(Connection conn, Student student, Predmet predmet) {
		return delete(conn, student.getId(), predmet.getId());
	}

	public boolean delete(Connection conn, int studentId, int predmetId) {
		boolean retVal = false;
		try {
			String update = "DELETE FROM pohadja WHERE student_id = " + studentId + " AND predmet_id = " + predmetId;
			Statement stmt = conn.createStatement();
			if(stmt.executeUpdate(update) == 1)
				retVal = true;
			stmt.close();
		} catch (SQLException ex) {
			log.fatal(ex);
			log.fatal("Ne moze se obrisati pohadjanje za studenta sa id: " + studentId + " i za predmet sa id: " + predmetId);
		}
		return retVal;
	}
	
	public boolean delete(Connection conn, Student student) {
		return deletePohadjanjaStudenta(conn, student.getId());
	}

	public boolean deletePohadjanjaStudenta(Connection conn, int studentId) {
		boolean retVal = false;
		try {
			String update = "DELETE FROM pohadja WHERE student_id = " + studentId;
			Statement stmt = conn.createStatement();
			if(stmt.executeUpdate(update) != 0)
				retVal = true;
			stmt.close();
		} catch (SQLException ex) {
			log.fatal(ex);
			log.fatal("Ne mogu se obrisati pohadjanja za studenta sa id: " + studentId);
		}
		return retVal;
	}
	
	public boolean delete(Connection conn, Predmet predmet) {
		return deletePohadjanjaPredmeta(conn, predmet.getId());
	}

	public boolean deletePohadjanjaPredmeta(Connection conn, int predmetId) {
		boolean retVal = false;
		try {
			String update = "DELETE FROM pohadja WHERE predmet_id = " + predmetId;
			Statement stmt = conn.createStatement();
			if(stmt.executeUpdate(update) != 0)
				retVal = true;
			stmt.close();
		} catch (SQLException ex) {
			log.fatal(ex);
			log.fatal("Ne moze se obrisati pohadjanje za predmet sa id: " + predmetId);
		}
		return retVal;
	}

}