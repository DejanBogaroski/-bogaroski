	drop table if exists pohadja;
	drop table if exists predaje;
	drop table if exists prijavaispita;
	drop table if exists studenti;
	drop table if exists predmeti;
	drop table if exists grad;
	drop table if exists nastavnici;	
	drop table if exists rokovi;
	
	
	create table studenti (
	student_id  integer AUTO_INCREMENT,
	indeks varchar(20),
	ime  varchar(20),
	prezime  varchar(20),
	grad varchar(20),
	primary key(student_id),
	INDEX (student_id)
	);

	create table grad (
	grad_id integer AUTO_INCREMENT,
	naziv varchar(20),
	ptt varchar(20),
	primary key (grad_id),
	INDEX (grad_id)
	);
	
	create table predmeti (
	predmet_id  integer AUTO_INCREMENT,
	naziv varchar(20),
	primary key(predmet_id),
	INDEX (predmet_id)
	);

	create table nastavnici (
	nastavnici_id integer AUTO_INCREMENT,
	imeprezime varchar(30),
	primary key (nastavnici_id),
	INDEX (nastavnici_id)
	);

	create table predaje (
	nastavnici_id integer not null,
	predmet_id integer not null,

	PRIMARY KEY(nastavnici_id, predmet_id),

	INDEX (nastavnici_id),
	FOREIGN KEY (nastavnici_id)
	                        REFERENCES nastavnici(nastavnici_id)
	                        ON DELETE RESTRICT,
	INDEX (predmet_id),
	FOREIGN KEY (predmet_id)
	                        REFERENCES predmeti(predmet_id)
	                        ON DELETE RESTRICT
	);

	create table rokovi(
	ispitnirok_id integer AUTO_INCREMENT,
	mesec varchar(20),
	primary key (ispitnirok_id),
	INDEX (ispitnirok_id)
	);
	
	create table prijavaispita (
	prijava_id integer AUTO_INCREMENT,	
	student_id integer not null,	
	predmet_id integer not null,
	ispitnirok_id integer not null,
	primary key (prijava_id),
	
	INDEX (student_id),
	FOREIGN KEY (student_id)
							REFERENCES studenti(student_id)
							ON DELETE RESTRICT,

	INDEX (predmet_id),
	FOREIGN KEY (predmet_id)
							REFERENCES predmeti(predmet_id)
							ON DELETE RESTRICT,

	INDEX (ispitnirok_id),
	FOREIGN KEY (ispitnirok_id)
							REFERENCES rokovi(ispitnirok_id)
							ON DELETE RESTRICT
	);
	
	

	create table pohadja (
	student_id  integer not null,
	predmet_id  integer not null,
	PRIMARY KEY(student_id, predmet_id),
	
	INDEX (student_id),
	FOREIGN KEY (student_id)
	                        REFERENCES studenti(student_id)
	                        ON DELETE RESTRICT,
	INDEX (predmet_id),
	FOREIGN KEY (predmet_id)
	                        REFERENCES predmeti(predmet_id)
	                        ON DELETE RESTRICT
	
	);
	
	insert into predmeti (naziv) values ('Algebra');
	insert into predmeti (naziv) values ('gradAnaliza 1');
	
	insert into studenti (indeks, ime, prezime, grad) values ('E 1/12', 'Student1', 'Studentovic1', 'Novi Sad');
	insert into studenti (indeks, ime, prezime, grad) values ('E 2/12', 'Student2', 'Studentovic2', 'Loznica');
	insert into studenti (indeks, ime, prezime, grad) values ('E 3/12', 'Student3', 'Studentovic3', 'Indjija');

	insert into grad (naziv, ptt) values ('Novi Sad', '21000');
	insert into grad (naziv, ptt) values ('Beograd', '11000');

	insert into rokovi (mesec) values ('Jun');
	insert into rokovi (mesec) values ('Jul');
	insert into rokovi (mesec) values ('Januar');
	insert into rokovi (mesec) values ('Oktobar');

	insert into pohadja values (1, 1);
	insert into pohadja values (1, 2);
	insert into pohadja values (2, 1);
	insert into pohadja values (3, 1);

	insert into prijavaispita (student_id, predmet_id, ispitnirok_id) values (1, 2, 3);
	insert into prijavaispita (student_id, predmet_id, ispitnirok_id) values (1, 1, 2);
	insert into prijavaispita (student_id, predmet_id, ispitnirok_id) values (2, 2, 3);
	insert into prijavaispita (student_id, predmet_id, ispitnirok_id) values (3, 2, 3);