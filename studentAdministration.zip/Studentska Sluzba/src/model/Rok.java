package model;

public class Rok {

	protected int id = 0;
	protected String mesec = "";

	public Rok() {
	}
	
	public Rok(String mesec) {
		this.mesec = mesec;

	}

	public Rok(int id, String mesec) {
		super();
		this.id = id;
		this.mesec = mesec;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMesec() {
		return mesec;
	}

	public void setMesec(String mesec) {
		this.mesec = mesec;
	}

	@Override
	public String toString() {
		return "Izabran rok: " + mesec;
	}
	
}