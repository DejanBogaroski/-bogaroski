package model;

public class Grad {

	protected int id;
	protected String naziv;
	protected String ptt;

	public Grad() {
	}

	public Grad(String naziv) {
		this.naziv = naziv;
	}

	public Grad(String naziv, int id) {
		this.id = id;
		this.naziv = naziv;
	}

	public Grad(String naziv, String ptt) {
		this.naziv = naziv;
		this.ptt = ptt;
	}

	public Grad(String naziv, int id, String ptt) {
		this.id = id;
		this.naziv = naziv;
		this.ptt = ptt;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getPtt() {
		return ptt;
	}

	public void setPtt(String ptt) {
		this.ptt = ptt;
	}
	
	@Override
	public String toString() {
		return "Grad: " + naziv + ", ID grada: " + id + ",PTT grada: " + ptt;
	}
	
}