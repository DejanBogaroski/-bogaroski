package model;

import java.util.ArrayList;
import java.util.List;

public class Student extends Osoba implements Comparable<Student>{

	protected String indeks;
	protected List<Predmet> predmeti;
	
	static final String ID_COL = "student_id";
	static final String INDEKS_COL = "indeks";
	static final String IME_COL = "ime";
	static final String PREZIME_COL = "prezime";
	static final String GRAD_COL = "grad";
	
	public Student() {
		this.id = -1;
		predmeti = new ArrayList<Predmet>();
	}
	
	public Student(int id, String indeks, String ime, String prezime,
			String grad) {
		this();
		this.id = id;
		this.indeks = indeks;
		this.ime = ime;
		this.prezime = prezime;
		this.grad = grad;
	}

	public Student(String indeks, String ime, String prezime, String grad) {
		this();
		this.indeks = indeks;
		this.ime = ime;
		this.prezime = prezime;
		this.grad = grad;
	}
	
	@Override
	public String toString() {
		return "Student sa indeksom:" + indeks + " cije je ime " + ime + " "
				+ prezime + " iz grada " + grad;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (this == obj)
			return true;
		if (obj instanceof Student) {
			Student objStudent = (Student) obj;
			if (this.indeks.equals(objStudent.indeks))
				return true;
		}
		return false;
	}
	
	@Override
	public int compareTo(Student o) {
		// ako je objekat u zagradi null ili njegov indeks je null onda je on na
		// kraju liste
		if ((o == null) || (o.indeks == null))
			return -1;
		// ako je this.index null onda je this na kraju liste
		if (this.indeks == null)
			return 1;
		// pozivamo compareTo metodu Stringa koja poredi leksikografski
		// stringove
		return this.indeks.compareTo(o.indeks);
	}

	public String getIndeks() {
		return indeks;
	}

	public void setIndeks(String indeks) {
		this.indeks = indeks;
	}

	public List<Predmet> getPredmeti() {
		return predmeti;
	}

	public void setPredmeti(List<Predmet> predmeti) {
		this.predmeti = predmeti;
	}
	
}