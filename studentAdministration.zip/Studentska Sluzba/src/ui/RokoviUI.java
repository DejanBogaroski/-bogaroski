package ui;

import java.util.List;

import model.Rok;
import utils.ScannerWrapper;
import dao.RokoviDAO;

public class RokoviUI {
	
RokoviDAO rokoviDAO = new RokoviDAO();
	
	public void meni() {
		int odluka = -1;
		while (odluka!=0) {
			ispisiMeni();
			System.out.println("Iaberite opciju: ");
			odluka = ScannerWrapper.ocitajCeoBroj();

			switch (odluka) {
			case 1:
				ispisiSveRokove();
				break;
			case 2:
				unosNovogRoka();
				break;
			default:
				break;
			}
			
		}
	}
	
	public void ispisiMeni() {
		System.out.println("\tOpcija 1 - ispisi sve rokove");
		System.out.println("\tOpcija 2 - Unesi novi rok.");
	
	}
	
	public void ispisiSveRokove() {
		List<Rok> rokovi = rokoviDAO.getAll(ApplicationUI.conn);
		for (int i = 0; i <rokovi.size() ; i++) {
			System.out.println(rokovi.get(i));
		}
	}
	
	public void unosNovogRoka() {
		System.out.println("Naziv");
		String rokNaziv = ScannerWrapper.ocitajTekst();
		
		Rok r = new Rok(rokNaziv);
		
		rokoviDAO.add(ApplicationUI.conn, r);
	}

}