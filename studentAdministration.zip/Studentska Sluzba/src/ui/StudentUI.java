package ui;

import java.util.List;

import utils.ScannerWrapper;
import model.Student;
import dao.StudentDAO;

public class StudentUI {
	
	private StudentDAO studentDAO = new StudentDAO();
	private PohadjaUI pohadjaUI;

	public void menu() { 

		pohadjaUI = ApplicationUI.pohadjaUI;
		int odluka = -1;
		while (odluka != 0) {
			StudentUI.ispisiMenu();
			System.out.print("opcija:");
			odluka = ScannerWrapper.ocitajCeoBroj();
			switch (odluka) {
			case 0:
				System.out.println("Izlaz");
				break;
			case 1:
				ispisiSveStudente();
				break;
			case 2:
				unosNovogStudenta();
				break;
			case 3:
				izmenaPodatakaOStudentu();
				break;
			case 4:
				predmetiStudenta();
				break;
			case 5:
				brisanjePodatakaOStudentu();
				break;
			case 6:
				sortiranjeStudenata();
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;
			}
		}
	}
	
	public static void ispisiMenu() {
		System.out.println("Rad sa studentima - opcije:");
		System.out.println("\tOpcija broj 1 - ispis svih Studenata");
		System.out.println("\tOpcija broj 2 - unos novog Studenta");
		System.out.println("\tOpcija broj 3 - izmena Studenta");
		System.out.println("\tOpcija broj 4 - predmeti Studenta");
		System.out.println("\tOpcija broj 5 - brisanje Studenta");
		System.out.println("\tOpcija broj 6 - sortiranje Studenta");
		System.out.println("\t\t ...");
		System.out.println("\tOpcija broj 0 - IZLAZ");	
	}
	
	public void ispisiSveStudente() {
		List<Student> sviStudenti = studentDAO.getAll(ApplicationUI.conn);
		for (int i = 0; i < sviStudenti.size(); i++) {
			System.out.println(sviStudenti.get(i));
		}
	}
	
	public void ispisiSveStudente(String orderClause) {
		List<Student> sviStudenti = studentDAO.getAll(ApplicationUI.conn, orderClause);
		for (int i = 0; i < sviStudenti.size(); i++) {
			System.out.println(sviStudenti.get(i));
		}
	}
	
	public Student pronadjiStudenta() {
		Student retVal = null;
		System.out.print("Unesi indeks studenta:");
		String stIndex = ScannerWrapper.ocitajTekst();
		retVal = pronadjiStudenta(stIndex);
		if (retVal == null)
			System.out.println("Student sa indeksom " + stIndex
					+ " ne postoji u evidenciji");
		return retVal;
	}

	public Student pronadjiStudenta(String stIndex) {
		Student retVal = studentDAO.getStudentByIndeks(ApplicationUI.conn, stIndex);
		return retVal;
	}
	
	public void unosNovogStudenta() {
		System.out.print("Unesi indeks:");
		String stIndex = ScannerWrapper.ocitajTekst();
		stIndex = stIndex.toUpperCase();
		while (pronadjiStudenta(stIndex) != null) {
			System.out.println("Student sa indeksom " + stIndex
					+ " vec postoji");
			stIndex = ScannerWrapper.ocitajTekst();
		}
		System.out.print("Unesi ime:");
		String stIme = ScannerWrapper.ocitajTekst();
		System.out.print("Unesi prezime:");
		String stPrezime = ScannerWrapper.ocitajTekst();
		System.out.print("Unesi grad:");
		String stGrad = ScannerWrapper.ocitajTekst();

		Student st = new Student(stIndex, stIme, stPrezime, stGrad);
		studentDAO.add(ApplicationUI.conn, st);
	}
	
	public void izmenaPodatakaOStudentu() {
		Student st = pronadjiStudenta();
		if(st != null){
			int choice; 
			do{
				System.out.println(st);
				System.out.println("Izmena studenta - opcije:");
				System.out.println("\tOpcija broj 1 - indeks");
				System.out.println("\tOpcija broj 2 - ime");
				System.out.println("\tOpcija broj 3 - prezime");
				System.out.println("\tOpcija broj 4 - grad");
				System.out.println("\t\t ...");
				System.out.println("\tOpcija broj 0 - IZLAZ");
				System.out.print("opcija: ");
				choice = ScannerWrapper.ocitajCeoBroj();
				switch (choice) {
					case 1:
						System.out.print("Unesi novi indeks :");
						String stIndeks = ScannerWrapper.ocitajTekst();
						st.setIndeks(stIndeks);
						break;
					case 2:
						System.out.print("Unesi ime :");
						String stIme = ScannerWrapper.ocitajTekst();
						st.setIme(stIme);
						break;
					case 3:
						System.out.print("Unesi prezime:");
						String stPrezime = ScannerWrapper.ocitajTekst();
						st.setPrezime(stPrezime);
						break;
					case 4:
						System.out.print("Unesi grad:");
						String stGrad = ScannerWrapper.ocitajTekst();
						st.setGrad(stGrad);
						break;
				}
				studentDAO.update(ApplicationUI.conn, st);
			} while(choice != 0);
		}
	}
	
	public void predmetiStudenta() {
		Student st = pronadjiStudenta();
		if(st != null){
			pohadjaUI.student = st;
			pohadjaUI.menu();
		}
	}
	
	public void brisanjePodatakaOStudentu(){
		Student st  = pronadjiStudenta();
		if(st != null){
			studentDAO.delete(ApplicationUI.conn, st);
		}
	}
	
	public void sortiranjeStudenata(){
		int choice; 
		do{
			System.out.println("Sortiranje rezultata - opcije:");
			System.out.println("\tOpcija broj 1 - po prezimenu");
			System.out.println("\tOpcija broj 2 - po imenu");
			System.out.println("\tOpcija broj 3 - po broju indeksa");
			System.out.println("\t\t ...");
			System.out.println("\tOpcija broj 0 - IZLAZ");
			System.out.print("opcija: ");
			choice = ScannerWrapper.ocitajCeoBroj();
			switch (choice) {
			case 1:
				ispisiSveStudente("prezime");
				break;
			case 2:
				ispisiSveStudente("ime");
				break;
			case 3:
				ispisiSveStudente("indeks");
				break;
			}
		} while(choice != 0);
		
	}
	
}