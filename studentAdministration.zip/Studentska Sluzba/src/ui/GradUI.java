package ui;

import java.util.List;

import model.Grad;
import utils.ScannerWrapper;
import dao.GradDAO;

public class GradUI {

	GradDAO grad = new GradDAO();

	public void meni() {
		int odluka = -1;

		while (odluka != 0) {
			ispisiMeni();
			System.out.println("Opcija: ");
			odluka = ScannerWrapper.ocitajCeoBroj();
			switch (odluka) {
			case 0:
				System.out.println("izlaz");
			case 1:
				ispisiSveGradove();
				break;
			case 2:
				unosNovogGrada();
				break;
			default:
				System.out.println("Nepostojeca komanda!");
				break;
			}
		}
	}

	public void ispisiSveGradove() {
		List<Grad> sviGradovi = grad.getAll(ApplicationUI.conn);
		for (int i = 0; i < sviGradovi.size(); i++) {
			System.out.println(sviGradovi.get(i));
		}
	}

	public void unosNovogGrada() {
		System.out.print("Naziv:");
		String prNaziv = ScannerWrapper.ocitajTekst();
		System.out.print("Uneti PTT broj: ");
		String pttBroj = ScannerWrapper.ocitajTekst();

		Grad g = new Grad(prNaziv, pttBroj);
		grad.add(ApplicationUI.conn, g);
		System.out.println("-----Grad dodat-----");
	}

	private void ispisiMeni() {
		System.out.println("Rad nad gradovima - opcije: ");
		System.out.println("\tOpcija 1 - Ispisivanje svih gradova");
		System.out.println("\tOpcija 2 - Unos novog grada");
		System.out.println();
		System.out.println("\tOpcija broj 0 - IZLAZ");
	}
	
}