package ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import utils.ScannerWrapper;
import dao.UpisDAO;

public class ApplicationUI {

	private static Logger logger = LogManager.getLogger(ApplicationUI.class.toString());
	public static Connection conn;	
	
	static {
			try {
				// ucitavanje MySQL drajvera
				Class.forName("com.mysql.jdbc.Driver");
	
				// konekcija
				conn = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/jwts2", "root", "pass");
			} catch (ClassNotFoundException e) {
				logger.error(e);
			} catch (SQLException e) {
				logger.error(e);
			}		
		}
	
	public static  StudentUI studentUI = new StudentUI();
	public static  PredmetUI predmetUI = new PredmetUI();
	public static PohadjaUI pohadjaUI = new PohadjaUI();
	public static  GradUI gradUI = new GradUI();
	public static  UpisDAO upisDAO = new UpisDAO();
	public static RokoviUI rokoviUI = new RokoviUI();
	public static PrijavaIspitaUI prijavaDAO = new PrijavaIspitaUI();
	
	public static void main(String[] args) {
		
		logger.entry();
		
		int odluka = -1;
		while (odluka != 0) {
			ApplicationUI.ispisiMenu();
			
			System.out.print("opcija:");
			odluka = ScannerWrapper.ocitajCeoBroj();
			
			switch (odluka) {
			case 0:
				System.out.println("Izlaz iz programa");
				break;
			case 1:
				studentUI.menu();
				break;
			case 2:
				predmetUI.menu();
				break;
			case 3:
				gradUI.meni();
				break;
			case 4:
				upisDAO.upisi();
				break;
			case 5:
				rokoviUI.meni();
				break;
			case 6:
				prijavaDAO.meni();
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;
			}
		}
	
		logger.exit(true);
		
	}
		
	public static void ispisiMenu() {
		System.out.println("Studentska Sluzba - Osnovne opcije:");
		System.out.println("\tOpcija broj 1 - Rad sa studentima");
		System.out.println("\tOpcija broj 2 - Rad sa predmetima");
		System.out.println("\tOpcija broj 3 - Rad sa gradovima");
		System.out.println("\tOpcija 4 - upisi");
		System.out.println("\tOpcija 5 - rad sa rokovima");
		System.out.println("\tOpcija 6 - prijava ispita");
		System.out.println("\t\t ...");
		System.out.println("\tOpcija broj 0 - IZLAZ IZ PROGRAMA");
	}
	
}