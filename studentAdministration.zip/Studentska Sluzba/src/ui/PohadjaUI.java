package ui;

import java.util.List;

import dao.PohadjaDAO;
import utils.ScannerWrapper;
import model.Predmet;
import model.Student;

public class PohadjaUI {

	private PohadjaDAO pohadjaDAO = new PohadjaDAO();
	private StudentUI studentUI;
	private PredmetUI predmetUI;
	public Student student = null;
	public Predmet predmet = null;

	public void menu() {
		studentUI = ApplicationUI.studentUI;
		predmetUI = ApplicationUI.predmetUI;
		int odluka = -1;
		while (odluka != 0) {
			ispisiMenu();
			System.out.print("opcija:");
			odluka = ScannerWrapper.ocitajCeoBroj();
			switch (odluka) {
			case 0:
				System.out.println("Izlaz");
				break;
			case 1:
				ispisiSve();
				break;
			case 2:
				dodavanje();
				break;
			case 3:
				skidanje();
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;
			}
		}
		student = null;
		predmet = null;
	}

	public void ispisiMenu() {
		if (student != null) {
			System.out.println("Student: " + student);
			System.out.println("Rad sa predmetima studenta - opcije:");
			System.out.println("\tOpcija broj 1 - ispis svih predmeta");
			System.out.println("\tOpcija broj 2 - dodavanje predmeta studentu");
			System.out.println("\tOpcija broj 3 - skidanje predmeta studentu");
			System.out.println("\t\t ...");
			System.out.println("\tOpcija broj 0 - IZLAZ");
		} else {
			System.out.println("Predmet: " + predmet);
			System.out.println("Rad sa studentima predmeta - opcije:");
			System.out.println("\tOpcija broj 1 - ispis svih studenata");
			System.out
					.println("\tOpcija broj 2 - dodavanje studenta na predmet");
			System.out
					.println("\tOpcija broj 3 - skidanje studenta sa predmeta");
			System.out.println("\t\t ...");
			System.out.println("\tOpcija broj 0 - IZLAZ");
		}
	}

	public void ispisiSve() {
		if (student != null) {
			ispisiSvePredmete();
		} else {
			ispisiSveStudente();
		}
	}

	public void ispisiSveStudente() {
		List<Student> sviStudenti = pohadjaDAO.getStudentiByPredmetId(
				ApplicationUI.conn, predmet.getId());
		for (int i = 0; i < sviStudenti.size(); i++) {
			System.out.println(sviStudenti.get(i));
		}
	}

	public void ispisiSvePredmete() {
		List<Predmet> sviPredmeti = pohadjaDAO.getPredmetiByStudentId(
				ApplicationUI.conn, student.getId());
		for (int i = 0; i < sviPredmeti.size(); i++) {
			System.out.println(sviPredmeti.get(i));
		}
	}

	public void dodavanje() {
		if (student != null) {
			dodavanjePredmeta();
		} else {
			dodavanjeStudenta();
		}
	}

	public void dodavanjeStudenta() {
		Student st = studentUI.pronadjiStudenta();
		if (st != null) {
			pohadjaDAO.add(ApplicationUI.conn, st.getId(), predmet.getId());
		}
	}

	public void dodavanjePredmeta() {
		Predmet pred = predmetUI.pronadjiPredmet();
		if (pred != null) {
			pohadjaDAO.add(ApplicationUI.conn, student.getId(), pred.getId());
		}
	}

	public void skidanje() {
		if (student != null) {
			skidanjePredmeta();
		} else {
			skidanjeStudenta();
		}
	}

	public void skidanjeStudenta() {
		Student st = studentUI.pronadjiStudenta();
		if (st != null) {
			pohadjaDAO.delete(ApplicationUI.conn, st.getId(), predmet.getId());
		}
	}

	public void skidanjePredmeta() {
		Predmet pred = predmetUI.pronadjiPredmet();
		if (pred != null) {
			pohadjaDAO.delete(ApplicationUI.conn, student.getId(), pred.getId());
		}
	}
	
}