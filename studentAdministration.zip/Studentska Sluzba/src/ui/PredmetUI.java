package ui;

import java.util.List;

import utils.ScannerWrapper;
import model.Predmet;
import dao.PredmetDAO;

public class PredmetUI {
	
	private PredmetDAO predmetDAO = new PredmetDAO();
	private PohadjaUI pohadjaUI;
	
	public void menu() {
		pohadjaUI = ApplicationUI.pohadjaUI;
		int odluka = -1;
		while (odluka != 0) {
			ispisiMenu();
			System.out.print("opcija:");
			odluka = ScannerWrapper.ocitajCeoBroj();
			switch (odluka) {
			case 0:
				System.out.println("Izlaz");
				break;
			case 1:
				ispisiSvePredmete();
				break;
			case 2:
				unosNovogPredmeta();
				break;
			case 3:
				izmenaPodatakaOPredmetu();
				break;
			case 4:
				studentiPredmeta();
				break;
			case 5:
				brisanjePodatakaOPredmetu();
				break;
			case 6:
				ispisiSvePredmete("naziv");
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;
			}
		}
	}
	
	public void ispisiMenu() {
		System.out.println("Rad sa predmetima - opcije:");
		System.out.println("\tOpcija broj 1 - ispis svih Predmeta");
		System.out.println("\tOpcija broj 2 - unos novog Predmeta");
		System.out.println("\tOpcija broj 3 - izmena naziva Predmeta");
		System.out.println("\tOpcija broj 4 - studenti Predmeta");
		System.out.println("\tOpcija broj 5 - brisanje Predmeta");
		System.out.println("\tOpcija broj 6 - sortiranje Predmeta po nazivu");
		System.out.println("\t\t ...");
		System.out.println("\tOpcija broj 0 - IZLAZ");
	}

	public void ispisiSvePredmete() {
		List<Predmet> sviPredmeti = predmetDAO.getAll(ApplicationUI.conn);
		for (int i = 0; i < sviPredmeti.size(); i++) {
			System.out.println(sviPredmeti.get(i));
		}
	}

	public void ispisiSvePredmete(String orderClause) {
		List<Predmet> sviPredmeti = predmetDAO.getAll(ApplicationUI.conn,
				orderClause);
		for (int i = 0; i < sviPredmeti.size(); i++) {
			System.out.println(sviPredmeti.get(i));
		}
	}

	public Predmet pronadjiPredmet() {
		Predmet retVal = null;
		System.out.print("Unesi id predmeta:");
		int id = ScannerWrapper.ocitajCeoBroj();
		retVal = pronadjiPredmet(id);
		if (retVal == null)
			System.out.println("Predmet sa id-om " + id
					+ " ne postoji u evidenciji");
		return retVal;
	}

	public Predmet pronadjiPredmet(int id) {
		Predmet retVal = predmetDAO.getPredmetById(ApplicationUI.conn, id);
		return retVal;
	}

	public void unosNovogPredmeta() {
		System.out.print("Naziv:");
		String prNaziv = ScannerWrapper.ocitajTekst();

		Predmet pred = new Predmet(prNaziv);
		predmetDAO.add(ApplicationUI.conn, pred);
	}

	public void izmenaPodatakaOPredmetu() {
		Predmet pred = pronadjiPredmet();
		if (pred != null) {
			System.out.println(pred);

			System.out.print("Unesi novi naziv :");
			String prNaziv = ScannerWrapper.ocitajTekst();
			pred.setNaziv(prNaziv);
			predmetDAO.update(ApplicationUI.conn, pred);
		}
	}

	public void studentiPredmeta() {
		Predmet pred = pronadjiPredmet();
		if (pred != null) {
			pohadjaUI.predmet = pred;
			pohadjaUI.menu();
		}
	}

	public void brisanjePodatakaOPredmetu() {
		Predmet pred = pronadjiPredmet();
		if (pred != null) {
			predmetDAO.delete(ApplicationUI.conn, pred);
		}
	}

}