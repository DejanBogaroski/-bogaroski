package ui;

import model.Student;
import utils.ScannerWrapper;
import dao.StudentDAO;

public class PrijavaIspitaUI {

	PredmetUI predmetUI = new PredmetUI();
	StudentDAO studentDAO = new StudentDAO();

	public void meni() {
		int odluka = -1;
		while (odluka!=0) {
			ispisiMeni();
			System.out.println("Opcija: ");
			odluka = ScannerWrapper.ocitajCeoBroj();
			switch (odluka) {
			case 1:
				meniZaDodavanjePrijava();
				break;

			default:
				break;
			}	
		}
	}

	public void ispisiMeni() {
		System.out.println("*** Meni za prijavu ispita ***");
		System.out.println("\n\tOpcija 1 - dodavanje prijave");
	}

	public Student meniZaDodavanjePrijava() {
		String index;
		System.out.println("Unesite idneks studenta: ");
		index = ScannerWrapper.ocitajTekst();
		return studentDAO.getStudentByIndeks(ApplicationUI.conn, index);
	}
	
}