package utils;

import java.util.Scanner;

public class ScannerWrapper {
	
static Scanner sc = new Scanner(System.in);
	
	public static String ocitajTekst(){
		String tekst = "";
		while(tekst == null || tekst.equals(""))
			tekst = sc.nextLine();
		
		return tekst;
	}
		
	public static int ocitajCeoBroj(){
		int ceoBroj = 0;
		boolean ocitan = false;
		while(ocitan == false) {
			try {
				ceoBroj = sc.nextInt();
				sc.nextLine();
				ocitan = true;
			} catch (Exception e) {
				System.out.println("GRESKA - Pogresno unsesena vrednost za ceo broj, pokusajte ponovo: ");
				sc.nextLine();
			}
		}
		return ceoBroj;
	}
		
	public static float ocitajRealanBroj(){
		float realanBroj = 0;
		boolean ocitan = false;
		while(ocitan == false) {
			try {
				realanBroj = sc.nextFloat();
				sc.nextLine();
				ocitan = true;
			} catch (Exception e) {
				System.out.println("GRESKA - Pogresno unsesena vrednost za realan broj, pokusajte ponovo: ");
				sc.nextLine();
			}
		}
		return realanBroj;
	}
		
	public static char ocitajKarakter(){
		char karakter = ' ';
		boolean ocitan = false;
		while(ocitan == false) {
			try {
				String text = sc.next();
				karakter = text.charAt(0);
				ocitan = true;
			} catch (Exception e) {
				System.out.println("GRESKA - Pogresno unsesena vrednost za karakter, pokusajte ponovo: ");
				sc.nextLine();
			}
		}
		return karakter;
	}
	
	public static char ocitajOdlukuOPotvrdi(String tekst){
		System.out.println("Da li zelite " + tekst + " [Y/N]:");
		char odluka = ' ';
		while( !(odluka == 'Y' || odluka == 'N') ){
			odluka = ocitajKarakter();
			if (!(odluka == 'Y' || odluka == 'N')) {
				System.out.println("Opcije su Y ili N");
			}
		}
		return odluka;
	}

}