$('#search').keyup(function() {
    var searchField = $('#search').val();
    var myExp = new RegExp(searchField, "i");
    $.getJSON('data.json', function(data) {
        var output = '<ul class="searchresults">';
        $.each(data, function(key, val) {
           if((val.firstname.search(myExp) != -1) || (val.bio.search(myExp) != -1)) {
               output += '<li>';
               output += '<h2>' + val.firstname + ' ' + val.lastname +'</h2>';
               output += '<img src="images/' + val.lastname + '.jpg" alt="' + val.firstname + '" />';
               output += '<p>' + val.bio + '</p>';
               output += '</li>';
           } 
        });
        output += '</li>';
        $('#update').html(output);
    });
});